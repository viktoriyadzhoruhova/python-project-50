### Hexlet tests, Maintainability and linter status:
[![Actions Status](https://github.com/viktoriyadzhoruhova/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/viktoriyadzhoruhova/python-project-50/actions)

# python-package

[![Github Actions Status](https://github.com/hexlet-boilerplates/python-package/workflows/Python%20CI/badge.svg)](https://github.com/hexlet-boilerplates/python-package/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cb7aa6e6b19f122697e2/maintainability)](https://codeclimate.com/github/viktoriyadzhoruhova/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/df66c0cbbeca7d822f23/test_coverage)](https://codeclimate.com/github/hexlet-boilerplates/python-package/test_coverage)

### Links

This project was built using these tools:

| Tool                                                                        | Description                                             |
|-----------------------------------------------------------------------------|---------------------------------------------------------|
| [poetry](https://python-poetry.org/)                                        | "Python dependency management and packaging made easy"  |
| [Py.Test](https://pytest.org)                                               | "A mature full-featured Python testing tool"            |
| [flake8](https://flake8.pycqa.org/)                                         | "Your tool for style guide enforcement" |

---

[![Hexlet Ltd. logo](https://raw.githubusercontent.com/Hexlet/assets/master/images/hexlet_logo128.png)](https://hexlet.io/?utm_source=github&utm_medium=link&utm_campaign=python-package)

This repository is created and maintained by the team and the community of Hexlet, an educational project. [Read more about Hexlet](https://hexlet.io/?utm_source=github&utm_medium=link&utm_campaign=python-package).

See most active contributors on [hexlet-friends](https://friends.hexlet.io/).