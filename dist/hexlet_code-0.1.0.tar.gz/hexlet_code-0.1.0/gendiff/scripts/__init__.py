from .gendiff import main
